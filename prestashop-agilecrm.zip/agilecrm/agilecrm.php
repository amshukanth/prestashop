<?php   
if (!defined('_PS_VERSION_')) {
  exit;
}

class AgileCRM extends Module{

  	public function __construct()
  	{
	    $this->name = 'agilecrm';
	    $this->tab = 'front_office_features';
	    $this->version = '1.0.0';
	    $this->author = 'AgileCRM';
	    $this->need_instance = 0;
	    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_); 
	    $this->bootstrap = true;
	 
	    parent::__construct();
	 
	    $this->displayName = $this->l('AgileCRM');
	    $this->description = $this->l('Agile CRM is an all-in-one, affordable and next-gen Customer Relationship Management (CRM) software with marketing, sales and service automation, built with love for small businesses.');
	 
	    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	 	   
 	}

 	public function install()
	{
	  	if (Shop::isFeatureActive()) {
		  Shop::setContext(Shop::CONTEXT_ALL);
		}

		return (parent::install()
            && $this->registerHook('leftColumn')
            && $this->registerHook('header')  
            && $this->registerHook('actionCustomerAccountAdd')
            && $this->registerHook('actionValidateOrder')   
            && $this->registerHook('actionOrderStatusUpdate') 
            && $this->registerHook('actionOrderStatusUpdate') 

        );

	}

	public function uninstall()
	{ 
	  if (!parent::uninstall()) {
	    return false;
	  }
	 
	  return true;
	}
	
	public function hookDisplayHeader($params)
	{

	    $this->context->smarty->assign(
	        array(
	          'agile_domain' => Configuration::get('AGILE_DOMAIN'),
	          'agile_rest_api_key' => Configuration::get('AGILE_REST_API_KEY'),
	          'agile_sync_customers' => Configuration::get('AGILE_SYNC_CUSTOMERS'),
	          'agile_sync_orders' => Configuration::get('AGILE_SYNC_ORDERS'),
	          'agile_webrules' => Configuration::get('AGILE_SYNC_WEBRULES'),
	          'agile_webstats' => Configuration::get('AGILE_SYNC_WEBSTATS')
	      	)
	  	);
	    return $this->display(__FILE__, 'agile_script.tpl');
	  	
	} 

	
	public function getContent()
	{
	    $output = null;
	 
	    if (Tools::isSubmit('submit'.$this->name))
	    {
	        $agile_domain = strval(Tools::getValue('AGILE_DOMAIN'));
	        $agile_email = strval(Tools::getValue('AGILE_EMAIL'));
	        $agile_rest_api_key = strval(Tools::getValue('AGILE_REST_API_KEY'));
	        $sync_customers = strval(Tools::getValue('AGILE_SYNC_CUSTOMERS'));
	        $sync_orders = strval(Tools::getValue('AGILE_SYNC_ORDERS'));
	        $sync_webrules = strval(Tools::getValue('AGILE_SYNC_WEBRULES'));
	        $sync_webstats = strval(Tools::getValue('AGILE_SYNC_WEBSTATS'));
	        $import_customers = strval(Tools::getValue('AGILE_IMPORT_CUSTOMERS'));	     	    	      	        

	        $result = $this->curl_wrap("api-key",null, "GET", "application/json", $agile_domain, $agile_email, $agile_rest_api_key);
	        $arr = json_decode($result, TRUE);
	        extract($arr);
	        $rest_api = $api_key;
	        
	        if (!$rest_api){
	            $output .= $this->displayError($this->l('Invalid Configuration value'));
	        }
	        else
	        {               		      	
	            Configuration::updateValue('AGILE_DOMAIN', $agile_domain);
	            Configuration::updateValue('AGILE_EMAIL', $agile_email);
	            Configuration::updateValue('AGILE_REST_API_KEY', $agile_rest_api_key);
	            Configuration::updateValue('AGILE_SYNC_CUSTOMERS', $sync_customers);
	            Configuration::updateValue('AGILE_SYNC_ORDERS', $sync_orders);
	            Configuration::updateValue('AGILE_SYNC_WEBRULES', $sync_webrules);
	            Configuration::updateValue('AGILE_SYNC_WEBSTATS', $sync_webstats);
	            Configuration::updateValue('AGILE_IMPORT_CUSTOMERS', $import_customers);
	            
	            if(Configuration::get('AGILE_IMPORT_CUSTOMERS') == "yes"){
	           		$customers = Customer::getCustomers();
	        		foreach($customers as $customer){
	        			$email = $customer['email'];
	        			$firstname = $customer['firstname'];
	        			$lastname = $customer['lastname'];
	        			$this->agile_add_contact($email, $firstname, $lastname);
	        		}	        		
	        	}	  

	            $output .= $this->displayConfirmation($this->l('Settings updated'));
	        }
	    }
	 	$output .= "<div style='padding:10px;background:white;border:solid 1px #d3d8db;border-radius:5px'>Do not have an Agile Account? <a target='_blank' href='https://www.agilecrm.com/pricing?utm_source=prestashop&utm_medium=website&utm_campaign=integration' style='text-decoration:none'>Create account</a> and fill the details below</div><br/>";
	    return $output.$this->displayForm();
	}

	public function hookActionCustomerAccountAdd($params)
	{
		$agile_domain = Configuration::get('AGILE_DOMAIN');
        //$agile_email = Configuration::get('AGILE_EMAIL');
        $agile_rest_api_key = Configuration::get('AGILE_REST_API_KEY');

        $sync_customers = Configuration::get('AGILE_SYNC_CUSTOMERS');	
        
        if($sync_customers == "yes"){
        	$email = $params['newCustomer']->email;
        	$firstname = $params['newCustomer']->firstname;
        	$lastname = $params['newCustomer']->lastname;
        	$this->agile_add_contact($email, $firstname, $lastname);
		    		
        }

		return true;
	}

	public function agile_add_contact($email, $firstname, $lastname)
	{
		$result = $this->curl_wrap("contacts/search/email/".$email, null, "GET", "application/json");
    	$result = json_decode($result, false, 512, JSON_BIGINT_AS_STRING);
    	
    	if(count($result)>0)
	        $contact_id = $result->id;
	    else
	        $contact_id = "";

	    if($contact_id == "")
	    {
	        $contact_json = array(
	              "tags"=>array("Prestashop"),
	              "properties"=>array(
	                array(
	                  "name"=>"first_name",
	                  "value"=> $firstname,
	                  "type"=>"SYSTEM"
	                ),
	                 array(
	                  "name"=>"last_name",
	                  "value"=>$lastname,
	                  "type"=>"SYSTEM"
	                ),
	                array(
	                  "name"=>"email",
	                  "value"=>$email,
	                  "type"=>"SYSTEM"
	                ),  
	              )
	            );
	        $contact_json = json_encode($contact_json);
	        $curln = $this->curl_wrap("contacts", $contact_json, "POST", "application/json");		            
	    }		 
	}

	public function hookActionValidateOrder($params)
	{	
		$sync_customers = Configuration::get('AGILE_SYNC_CUSTOMERS');
		$sync_orders = Configuration::get('AGILE_SYNC_ORDERS');
		$email = $params['customer']->email;

		if($sync_orders == "yes"){
			$result = $this->curl_wrap("contacts/search/email/".$email, null, "GET", "application/json");
            $result = json_decode($result, false, 512, JSON_BIGINT_AS_STRING);
            if(count($result)>0)
            {
            	$contact_id = $result->id;
	            $productname = array();
	            $address = new Address($params['cart']->id_address_delivery);
	            $street = $address->address2 == "" ? $address->address1 : $address->address1.",".$address->address2;
	            $city = $address->city;
	            $state = State::getNameById($address->id_state);
	            $country = $address->country;      

	            foreach ($params['order']->product_list as $product_item) {
	                $productname[] = $this->fn_js_escape($product_item['name']);
	            }
	            $noteproductname = implode(',',$productname);
	            $productname = implode('","',$productname);
	            $Str = $productname;
	            $Str = preg_replace('/[^a-zA-Z0-9_.]/', '_', $Str);
	            $contact_json = array(
	                "id" => $contact_id, 
	               "tags" => array($Str)
	            );

	           $contact_json = stripslashes(json_encode($contact_json));
	           $curltags = $this->curl_wrap("contacts/edit/tags", $contact_json, "PUT", "application/json");
	           $billingaddress = $street.",".$city.",".$state.",".$country;
	           $grandtotal = $params['order']->total_paid;
	           $orderid = $params['order']->id;	           
	        
	            $note_json = array(
	              "subject"=> "Order# ". $orderid ,
	              "description"=>"Order status: ".$params['orderStatus']->name."\nTotal amount:".$grandtotal."\nItems(id-qty):".$noteproductname."\nBilling:".$billingaddress,
	              "contact_ids"=>array($contact_id)
	            );

	            $note_json = json_encode($note_json);
	            $curls = $this->curl_wrap("notes", $note_json, "POST", "application/json");

	            if($sync_customers == "yes"){
	            	$billing_address_sync = array(
		              "address"=>$street,
		              "city"=>$city,
		              "state"=>$state,
		              "country"=>$country
		            );

	            	$contact_json_update = array(
	                  "id"=>$contact_id, //It is mandatory field. Id of contact
	                  "tags"=>array("Prestashop"),
	                  "properties"=>array(
	                    array(
	                      "name"=>"first_name",
	                      "value"=>$params['customer']->firstname,
	                      "type"=>"SYSTEM"
	                    ),
	                    array(
	                      "name"=>"last_name",
	                      "value"=>$params['customer']->lastname,
	                      "type"=>"SYSTEM"
	                    ),
	                    array(
	                      "name"=>"email",
	                      "value"=>$params['customer']->email,
	                      "type"=>"SYSTEM"
	                    ),  
	                    array(
	                        "name"=>"address",
	                        "value"=>json_encode($billing_address_sync),
	                        "type"=>"SYSTEM"
	                    ),
	                    array(
	                        "name"=>"phone",
	                        "value"=>$address->phone,
	                        "type"=>"SYSTEM"
	                    )
	                  )
	                );
	                $contact_json_update = json_encode($contact_json_update);
	                $curlupdate = $this->curl_wrap("contacts/edit-properties", $contact_json_update, "PUT", "application/json");
	            }
            }          
            
		}
		return true;
	}

	public function hookActionOrderStatusUpdate($params)
	{
		
		file_put_contents("changeorder.txt", print_r($params, true));	
		return true;
	}


	public function fn_js_escape($str)
	{
	    return strtr($str, array('\\' => '\\\\',  "'" => "\\'", '"' => '\\"', "\r" => '\\r', "\n" => '\\n', "\t" => '\\t', '</' => '<\/', "/" => '\\/'));
	}

	public function displayForm()
	{
	    // Get default language
	    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
	     
	    // Init Fields form array
	    $fields_form[0]['form'] = array(
	        'legend' => array(
	            'title' => $this->l('Account Settings'),
	        ),
	        'input' => array(
	            array(
	                'type' => 'text',
	                'label' => $this->l('Domain'),
	                'name' => 'AGILE_DOMAIN',
	                'size' => 20,
	                'required' => true
	            ),
	            array(
	                'type' => 'text',
	                'label' => $this->l('Email'),
	                'name' => 'AGILE_EMAIL',
	                'size' => 20,
	                'required' => true
	            ),
	            array(
	                'type' => 'text',
	                'label' => $this->l('Rest API Key'),
	                'name' => 'AGILE_REST_API_KEY',
	                'size' => 20,
	                'required' => true
	            )
	        ),
	        'submit' => array(
	            'title' => $this->l('Save'),
	            'class' => 'btn btn-default pull-right'
	        )
	    );

	    $options = array(
					  array(
					    'id_option' => 'yes',       // The value of the 'value' attribute of the <option> tag.
					    'name' => 'Yes'    // The value of the text content of the  <option> tag.
					  ),
					  array(
					    'id_option' => 'no',
					    'name' => 'No'
					  ),
					);

	    $fields_form[1]['form'] = array(
	        'legend' => array(
	            'title' => $this->l('Sync Settings'),
	        ),
	        'input' => array(
	            array(
	                'type' => 'select',
	                'label' => $this->l('Sync Customers to Agile'),
	                'desc' => $this->l('Sync registered users to Agile'),
	                'name' => 'AGILE_SYNC_CUSTOMERS',
	                'options' => array(
	                	'query' => $options,
	                	'id' => "id_option",
	                	'name' => "name"
	                	),	       
	            ),
	            array(
	                'type' => 'select',
	                'label' => $this->l('Sync Orders as Notes in Agile'),
	                'desc' => $this->l('Sync purchased orders'),
	                'name' => 'AGILE_SYNC_ORDERS',
	                'options' => array(
	                	'query' => $options,
	                	'id' => "id_option",
	                	'name' => "name"
	                	),	       
	            ),
	            array(
	                'type' => 'select',
	                'label' => $this->l('Webrules'),
	                'desc' => $this->l('Popups'),
	                'name' => 'AGILE_SYNC_WEBRULES',
	                'options' => array(
	                	'query' => $options,
	                	'id' => "id_option",
	                	'name' => "name"
	                	),	       
	            ),
	            array(
	                'type' => 'select',
	                'label' => $this->l('Webstats'),
	                'desc' => $this->l('Log user activity'),
	                'name' => 'AGILE_SYNC_WEBSTATS',
	                'options' => array(
	                	'query' => $options,
	                	'id' => "id_option",
	                	'name' => "name"
	                	),	       
	            ),
	            array(
	                'type' => 'select',
	                'label' => $this->l('Import Customers'),
	                'desc' => $this->l('Import Existing Customers to Agile'),
	                'name' => 'AGILE_IMPORT_CUSTOMERS',
	                'options' => array(
	                	'query' => $options,
	                	'id' => "id_option",
	                	'name' => "name"
	                	),	       
	            )
	        ),
	        'submit' => array(
	            'title' => $this->l('Save'),
	            'class' => 'btn btn-default pull-right'
	        )
	    );
	    


	    $helper = new HelperForm();
	     
	    // Module, token and currentIndex
	    $helper->module = $this;
	    $helper->name_controller = $this->name;
	    $helper->token = Tools::getAdminTokenLite('AdminModules');
	    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
	     
	    // Language
	    $helper->default_form_language = $default_lang;
	    $helper->allow_employee_form_lang = $default_lang;
	     
	    // Title and toolbar
	    $helper->title = $this->displayName;
	    $helper->show_toolbar = true;        // false -> remove toolbar
	    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
	    $helper->submit_action = 'submit'.$this->name;
	    $helper->toolbar_btn = array(
	        'save' =>
	        array(
	            'desc' => $this->l('Save'),
	            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
	            '&token='.Tools::getAdminTokenLite('AdminModules'),
	        ),
	        'back' => array(
	            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
	            'desc' => $this->l('Back to list')
	        )
	    );
	     
	    // Load current value
	    $helper->fields_value['AGILE_DOMAIN'] = Configuration::get('AGILE_DOMAIN');
	    $helper->fields_value['AGILE_EMAIL'] = Configuration::get('AGILE_EMAIL');
	    $helper->fields_value['AGILE_REST_API_KEY'] = Configuration::get('AGILE_REST_API_KEY');
	    $helper->fields_value['AGILE_SYNC_CUSTOMERS'] = Configuration::get('AGILE_SYNC_CUSTOMERS');
	    $helper->fields_value['AGILE_SYNC_ORDERS'] = Configuration::get('AGILE_SYNC_ORDERS');
	    $helper->fields_value['AGILE_SYNC_WEBRULES'] = Configuration::get('AGILE_SYNC_WEBRULES');
	    $helper->fields_value['AGILE_SYNC_WEBSTATS'] = Configuration::get('AGILE_SYNC_WEBSTATS');
	    $helper->fields_value['AGILE_IMPORT_CUSTOMERS'] = Configuration::get('AGILE_IMPORT_CUSTOMERS');
	    return $helper->generateForm($fields_form);
	}

	public function curl_wrap($entity, $data, $method, $content_type, $agile_domain=null, $agile_email=null, $agile_rest_api_key=null) {

		if($agile_domain == NULL){
			$agile_domain = Configuration::get('AGILE_DOMAIN');
	        $agile_email = Configuration::get('AGILE_EMAIL');
	        $agile_rest_api_key = Configuration::get('AGILE_REST_API_KEY');
		}       

        if ($content_type == NULL) {
            $content_type = "application/json";
        }
       
        $agile_url = "https://" . $agile_domain . ".agilecrm.com/dev/api/" . $entity;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        curl_setopt($ch, CURLOPT_UNRESTRICTED_AUTH, true);
        switch ($method) {
            case "POST":
                $url = $agile_url;
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                break;
            case "GET":
                $url = $agile_url;
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
                break;
            case "PUT":
                $url = $agile_url;
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                break;
            case "DELETE":
                $url = $agile_url;
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
                break;
            default:
                break;
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Content-type : $content_type;", 'Accept : application/json'
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, $agile_email . ':' . $agile_rest_api_key);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }

}